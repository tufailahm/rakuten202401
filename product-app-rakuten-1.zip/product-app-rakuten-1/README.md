create table products
(
		productid integer,
		productName char(40),
		quantityOnHand integer,
		price integer
)
select * from products;

change your db credentials in DBConnection.java